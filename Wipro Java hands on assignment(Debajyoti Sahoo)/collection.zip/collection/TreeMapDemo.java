package collectionPackage;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class TreeMapDemo {
    TreeMap tm=new TreeMap();
    public int getphone(String name)
	{
		if (tm.containsKey(name))
			return (int)tm.get(name);
		else
			return 0;
	}
    public static <K,V> K getKey(Map<K,V> map,V value)
	{
		
	
	for(K key:map.keySet())
	{
		
		if(value.equals(map.get(key)))
		{
			return key;
		}
	}
	return null;
	}	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
         TreeMapDemo tmd=new TreeMapDemo();
         tmd.tm.put("Srija",123456789);
         tmd.tm.put("puja",123476549);
         int val=tmd.getphone("puja");
         
         Set set=tmd.tm.entrySet();
     	Iterator itr=set.iterator();
     	System.out.println(" Displaying the details of Tm Map:");
     	
     	while(itr.hasNext())
     	{
     		Map.Entry me=(Map.Entry)itr.next();
     		System.out.print(me.getKey()+":");
     		System.out.println(me.getValue());
     	}
     	System.out.println("get phone number:"+val);
        System.out.println("get name:"+getKey(tmd.tm,123456789));
	}
	

}
