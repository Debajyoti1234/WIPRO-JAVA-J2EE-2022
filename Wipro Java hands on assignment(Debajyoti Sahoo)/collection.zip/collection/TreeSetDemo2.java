package collectionPackage;

import java.util.TreeSet;

import java.util.Vector;
import java.util.Iterator;
import java.util.Set;
public class TreeSetDemo2{
	
	public static void main(String a[])
	{
			
		TreeSet<Employee> ts= new TreeSet<Employee>();
		Employee e1=new Employee(123,"Srija",60000f);
		Employee e2=new Employee(1234,"Srinija",55000f);
		Employee e3=new Employee(1235,"Pujs",35000f);
		Employee e4=new Employee(1236,"James",40000f);
		Employee e5=new Employee(1237,"Jos",20000f);
		Employee e6=new Employee(1238,"Michal",15000f);
		Employee e7=new Employee(1239,"Sam",70000f);
		Employee e8=new Employee(12,"Maxi",45000f);
		                                  
		ts.add(e1);
		ts.add(e2);
		ts.add(e3);
		ts.add(e4);
		ts.add(e5);
		ts.add(e6);
		ts.add(e7);
		ts.add(e8);
		Iterator itr=ts.iterator();
		while(itr.hasNext())
		{
			Object obj=itr.next();
			System.out.println(obj);
		}
		
	
	}
}
	


