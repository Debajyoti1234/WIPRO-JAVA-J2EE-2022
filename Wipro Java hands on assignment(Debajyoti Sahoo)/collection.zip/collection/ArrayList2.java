package collectionPackage;

import java.util.ArrayList;

public class ArrayList2 {
	public static void main(String a[])
	{
		ArrayList al=new ArrayList();
		al.add(20);
		al.add(30f);
		al.add(400.00);
		System.out.println(al);
	}

}
