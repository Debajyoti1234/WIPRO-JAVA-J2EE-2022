package collectionPackage;

import java.util.Iterator;
import java.util.Scanner;
import java.util.TreeSet;

public class TeeSetDemo {
	TreeSet<String> set=new TreeSet<String>(new StringComparator());
	String find(String name)
	{
		if(set.contains(name))
			return "Exist";
		else
			return "Not Exist";
	}
	public static void main(String a[])
{
     //TreeSet<String> set=new TreeSet<String>(new StringComparator());
		TeeSetDemo tsd=new TeeSetDemo();
		Scanner sc=new Scanner(System.in);
		
				
     tsd.set.add("a");
     tsd.set.add("b");
     tsd.set.add("c");
     tsd.set.add("d");
     tsd.set.add("f");
     Iterator it=tsd.set.iterator();
     while(it.hasNext())
     {
    	 Object o=it.next();
    	 System.out.println("Content in Treeset :"+o);
     }
    System.out.println("Enter a String:");
     String sa=sc.next();

     String name=tsd.find(sa);
     System.out.println("Element exist or not:"+name);
     
     
     
     
}
}
