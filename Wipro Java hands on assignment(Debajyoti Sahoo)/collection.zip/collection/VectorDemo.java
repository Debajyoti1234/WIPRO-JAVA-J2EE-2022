package collectionPackage;

import java.util.Collections;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.Vector;

public class VectorDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    Vector<Integer> v=new Vector<Integer>();
    v.add(20);
    v.add(35);
    v.add(200);
    v.add(1600);
    Enumeration e=Collections.enumeration(v);
    while(e.hasMoreElements())
    {
    	Object o=e.nextElement();
    	System.out.println("USing Enumeration Contents:"+o);
    }
    Iterator i=v.iterator();
    while(i.hasNext())
    {
    	Object o=i.next();
    	System.out.println("iterator:"+o);
    }
    ListIterator lt=v.listIterator();
    while(lt.hasNext())
    {
    	Object o=lt.next();
    	System.out.println("ListIterator:"+o);
    }
    
    
	}
	

}
