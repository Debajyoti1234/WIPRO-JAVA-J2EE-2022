package collectionPackage;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Scanner;

public class HashSetDemo {
   HashSet set=new HashSet<>();
   boolean addCountry(String countryName) {
	   
	   return set.add(countryName);
   }
   String findCountry(String countryName)
   {
	   if (set.contains(countryName))
	   {
		   return countryName;
	   }
	   else 
		   return "Not exist";
	   
   }
   public static void main(String a[])
   
   {
	   Scanner sc=new Scanner(System.in);
	   System.out.println("Enter the number of Elemts  :");
	   
	   int n=sc.nextInt();
	 
	  HashSetDemo hsd=new HashSetDemo();
	  
	
	  for(int i=0;i<n;i++)
	  {
		  String name=sc.next();
		  hsd.addCountry(name);
		  
	  }
	  String res=hsd.findCountry("srija");
	  System.out.println("findCountry:"+res);
	  System.out.println("Enter the elements og HS:");
	  Iterator it=hsd.set.iterator();
	  while(it.hasNext())
	  {
		  Object o=it.next();
		  System.out.print(o+" ");
	  }
	  
   }  
   
}
