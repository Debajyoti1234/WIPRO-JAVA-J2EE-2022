public class Assignment05 {

	public static void main(String[] args) {
		char var = '@';
		
		if((var >= 65 && var <= 90) || (var >= 97 && var <= 122) ) {
			System.out.println("Alphabet");
		}
		else if(var >= 48 && var <= 57) {
			System.out.println("Number");
		}
		else {
			System.out.println("Special Character");
		}
	}

}