import java.util.Scanner;
class Assignment16 {
    public static void main(String[] args) {
            Scanner in = new Scanner(System.in);
            System.out.print("Enter a integer: ");
            int n = in.nextInt();
            if(n == revInt(n))
                System.out.println(n  + " is a palindrome");
            else
                System.out.println(n  + " is not a palindrome");
    
    }

    static int revInt(int n) {
        int rev = 0;
        while(n > 0) {
            rev = rev*10 + (n%10);
            n/= 10;
        }
        return rev;
    }
}