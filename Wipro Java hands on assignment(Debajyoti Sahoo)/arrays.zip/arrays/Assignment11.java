class Assignment11

{
private static int[] a = {1,4,1,4};

public static void main ( String args [] )

{

int i , k=0 ;


for ( i=0;i<a.length;i++)

{

System.out.println ( a[ i ] + " " ) ;

}


for ( i=0;i<a.length;i++)

{

if ( a [ i ] == 1 || a [ i ] == 4 )

k++;

}

if ( k == a.length )

System.out.println (" True ");

else

System.out.println (" False ");

}

}