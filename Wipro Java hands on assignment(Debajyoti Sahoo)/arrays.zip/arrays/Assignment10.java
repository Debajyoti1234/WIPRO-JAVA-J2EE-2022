public class Assignment10 {

	public static void getArrangedEvenOdd( int arr[], int n)
    {
        int i = -1, j = 0;
        while (j != n)
        {
            if (arr[j] % 2 == 0)
            {
                i++;
                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
            j++;
        }
        for (int k = 0; k < n; k++)
            System.out.print(arr[k] + " ");
    }
    public static void main(String args[])
    {
        int arr[] = { 1,0,1,0,0,1,1};
        int n = arr.length;
        getArrangedEvenOdd (arr, n);
    }
}