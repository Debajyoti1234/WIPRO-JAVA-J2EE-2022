INSERT INTO my_employee (
    employee_id,
    first_name,
    last_name,
    department_id, salary
) VALUES (
    100,'Steven', 'King', 90, 24000
),
values(
101, 'Neena', 'Kochar', 90, 17000
),
values(
102, 'Lex De', 'Haan', 90, 17000
),
values(
111, 'Isamael', 'Sciarra', 100, 7700
),
values(
112, 'Jose Manuel', 'Urman', 100, 7800
),
values(
204, 'Hermann' , 'Baer', 70, 1000
);

