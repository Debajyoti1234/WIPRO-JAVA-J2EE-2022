/*Write a JavaScript code which displays the current system date and time.
Save the code as Sample.js, invoke it using jjs tool and display the result.
*/

var today = new Date();
print(today);