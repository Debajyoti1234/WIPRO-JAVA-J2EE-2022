package com.wipro.test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.wipro.task.DailyTasks;

public class TestStringConcat {
	
	@Test
	public void TestConcat()
	{
		DailyTasks dt = new DailyTasks();
		String expRes = "Hello World";
		String actRes = dt.doStringConcat("Hello", "World");
		assertEquals(expRes, actRes);
	}
	
}
