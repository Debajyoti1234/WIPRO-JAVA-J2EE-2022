package com.wipro.test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import com.wipro.task.DailyTasks;

public class TestCheckPresence {
	
	@Test
	public void TestPresence()
	{
		DailyTasks dt = new DailyTasks();
		String str = "Hello World";
		String a = "d";
		boolean actRes = true;
		boolean expRes = dt.checkPresence(str, a);
		assertTrue(actRes);
		assertTrue(expRes);
		
		String str1 = "Hello World";
		String a1 = "a";
		boolean actRes1 = false;
		boolean expRes1 = dt.checkPresence(str1, a1);
		assertFalse(actRes1);
		assertFalse(expRes1);
	}
}
