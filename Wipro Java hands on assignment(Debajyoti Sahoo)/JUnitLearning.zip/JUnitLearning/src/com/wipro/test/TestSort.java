package com.wipro.test;

import static org.junit.Assert.assertArrayEquals;

import org.junit.Test;

import com.wipro.task.DailyTasks;

public class TestSort {
	
	@Test
	public void TestArraySort()
	{
		DailyTasks dt = new DailyTasks();
		int[] arr = new int[] {5,1,3,4};
		int[] expRes = new int[] {1,3,4,5};
		int[] actRes = dt.sortValues(arr);
		assertArrayEquals(expRes, actRes);
	}
	
}
