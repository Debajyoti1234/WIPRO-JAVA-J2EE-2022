package com.wipro.test;

import org.junit.runners.Suite;
import org.junit.runner.RunWith;

@RunWith(Suite.class)
@Suite.SuiteClasses({TestStringConcat.class, TestSort.class, TestCheckPresence.class})

public class TestSuite {
	
}
